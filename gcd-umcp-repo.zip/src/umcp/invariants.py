import numpy as np
import pandas as pd
from .defaults import DEFAULTS

def drift(xhat: pd.Series) -> pd.Series:
    return (xhat - xhat.shift(1)).abs().fillna(0.0)

def fidelity(omega: pd.Series) -> pd.Series:
    return 1.0 - omega

def entropy(omega: pd.Series, eps: float = DEFAULTS.eps) -> pd.Series:
    return -(1.0 - omega + eps).apply(np.log)

def curvature(xhat: pd.Series, K: int = DEFAULTS.K) -> pd.Series:
    acc = 0.0
    for k in range(1, K + 1):
        acc = acc + (xhat - xhat.shift(k))**2
    return (acc / K).fillna(0.0)

def reentry_delay(xhat: pd.Series,
                  lambda_: float = DEFAULTS.lambda_,
                  k: float = DEFAULTS.k,
                  eps_min: float = DEFAULTS.eps_min,
                  eps_max: float = DEFAULTS.eps_max,
                  L: int = DEFAULTS.L,
                  H_max: int = DEFAULTS.H_max) -> pd.Series:
    # EMA noise estimate on residuals of xhat vs. its own EMA
    ema = xhat.ewm(alpha=lambda_, adjust=False).mean()
    resid = (xhat - ema).abs()
    # MAD-like scale
    sigma = 1.4826 * resid.rolling(window=25, min_periods=5).median().fillna(resid.mean())
    tol = (k * sigma).clip(eps_min, eps_max)

    delays = np.zeros(len(xhat), dtype=int)
    xvals = xhat.values
    tolvals = tol.values

    for t in range(len(xhat)):
        tgt = xvals[t]
        # search backward
        found = False
        for d in range(1, min(H_max, t) + 1):
            if abs(tgt - xvals[t - d]) < tolvals[t]:
                # require L consecutive checks (debounce)
                ok = True
                for j in range(1, L):
                    if t - d - j < 0 or abs(tgt - xvals[t - d - j]) >= tolvals[t]:
                        ok = False
                        break
                if ok:
                    delays[t] = d
                    found = True
                    break
        if not found:
            delays[t] = 0
    return pd.Series(delays, index=xhat.index, dtype=int)

def integrity(F: pd.Series, S: pd.Series, omega: pd.Series, C: pd.Series, tauR: pd.Series,
              alpha: float = DEFAULTS.alpha) -> pd.Series:
    return F * np.exp(-S) * (1.0 - omega) * np.exp(-(alpha * C) / (1.0 + tauR))

def kappa(IC: pd.Series) -> pd.Series:
    # Avoid -inf by clipping very small values
    return np.log(IC.clip(lower=1e-300))
