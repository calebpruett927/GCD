from dataclasses import dataclass
import numpy as np
import pandas as pd

@dataclass(frozen=True)
class Contract:
    a: float
    b: float
    eps: float = 1e-8
    mode: str = "global_fixed"  # or "p1p99"

    def normalize(self, x: pd.Series) -> pd.Series:
        y = (x - self.a) / self.b
        return y.clip(0.0, 1.0)

def calibrate_p1p99(x: pd.Series, guard_low=0.05, guard_high=0.05) -> Contract:
    q1, q99 = np.quantile(x.dropna(), [0.01, 0.99])
    sref = q99 - q1
    a = q1 - guard_low * sref
    b = (q99 + guard_high * sref) - a
    return Contract(a=a, b=b)
