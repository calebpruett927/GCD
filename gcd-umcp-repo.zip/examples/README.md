# Examples

### Audit a synthetic switch

```bash
umcp audit examples/data/sine_switch.csv --col x --time t --out artifacts/audit.csv
umcp plot artifacts/audit.csv --out artifacts/audit.png
```

Open `artifacts/audit.csv` to inspect invariants and regimes, and `artifacts/audit.png` for a quick visualization.
