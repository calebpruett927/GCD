import pandas as pd

DEFAULT_GATES = {
    "stable": {"drift_lt": 0.038, "fidelity_gt": 0.90, "entropy_lt": 0.15, "curvature_lt": 0.14},
    "watch": {"drift_range": (0.038, 0.30)},
    "collapse": {"drift_ge": 0.30},
    "critical": {"ic_lt": 0.30},
}

def assign_regime(df: pd.DataFrame, gates: dict = None) -> pd.Series:
    g = gates or DEFAULT_GATES
    omega = df["omega"]
    F = df["F"]
    S = df["S"]
    C = df["C"]
    IC = df["IC"]

    regime = pd.Series(index=df.index, dtype="string")

    # Critical first
    regime[IC < g["critical"]["ic_lt"]] = "critical"

    # Collapse
    regime[(omega >= g["collapse"]["drift_ge"]) & regime.isna()] = "collapse"

    # Watch
    lo, hi = g["watch"]["drift_range"]
    regime[((omega >= lo) & (omega < hi)) & regime.isna()] = "watch"

    # Stable (all stable-band conditions)
    stable_mask = (
        (omega < g["stable"]["drift_lt"]) &
        (F > g["stable"]["fidelity_gt"]) &
        (S < g["stable"]["entropy_lt"]) &
        (C < g["stable"]["curvature_lt"])
    )
    regime[stable_mask & regime.isna()] = "stable"

    # Fill remaining as watch by default
    regime[regime.isna()] = "watch"
    return regime
