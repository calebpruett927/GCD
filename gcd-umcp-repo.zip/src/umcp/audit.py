import pandas as pd
import hashlib
from .contract import Contract, calibrate_p1p99
from .invariants import drift, fidelity, entropy, curvature, reentry_delay, integrity, kappa
from .regimes import assign_regime
from .defaults import DEFAULTS

def _sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(8192)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()

def audit_csv(csv_path: str, col: str, time_col: str = None, a=None, b=None, mode="global_fixed") -> pd.DataFrame:
    df = pd.read_csv(csv_path)
    x = df[col]
    if time_col and time_col in df.columns:
        idx = df[time_col]
    else:
        idx = range(len(df))

    if mode == "p1p99":
        contract = calibrate_p1p99(x)
    else:
        if a is None or b is None:
            # default to p1p99 if (a,b) not given
            contract = calibrate_p1p99(x)
        else:
            contract = Contract(a=a, b=b)

    xhat = contract.normalize(x)
    omega = drift(xhat)
    F = fidelity(omega)
    S = entropy(omega)
    C = curvature(xhat)
    tauR = reentry_delay(xhat)
    IC = integrity(F, S, omega, C, tauR, alpha=DEFAULTS.alpha)
    k = kappa(IC)

    out = pd.DataFrame({
        "t": idx,
        "x_raw": x,
        "x_hat": xhat,
        "omega": omega,
        "F": F,
        "S": S,
        "C": C,
        "tau_R": tauR,
        "IC": IC,
        "kappa": k,
    })
    out["regime"] = assign_regime(out)

    out.attrs["manifest"] = {
        "input_csv": csv_path,
        "sha256": _sha256_file(csv_path),
        "contract": {"a": contract.a, "b": contract.b, "eps": contract.eps, "mode": contract.mode},
        "defaults": DEFAULTS.model_dump(),
    }
    return out
