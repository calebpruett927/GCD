# GCD/UMCP/RCFT/ULRC — Docs

This repository provides a minimal but complete operational stack:

- **Contract & normalization** (freeze (a,b,ε), clip policy)
- **Invariants**: ω (drift), F, S, C, τ_R, IC, κ
- **Regime map** with canonical gates
- **Weld protocol** (κ-continuity check)
- **Manifest** (hashes + parameters) for audit reproducibility
