# Security Policy

No secrets in the repo. CI is read-only for public forks. Report issues via private channels when appropriate.
