import json
import click
from rich.console import Console
from rich.table import Table
from .audit import audit_csv
from .manifest import write_manifest
from .plots import plot_audit

console = Console()

@click.group()
def app():
    "UMCP audit CLI — compute invariants, assign regimes, and export manifests/plots."

@app.command("audit")
@click.argument("csv_path")
@click.option("--col", required=True, help="Column name with the raw observable.")
@click.option("--time", "time_col", default=None, help="Optional time/index column.")
@click.option("--a", type=float, default=None, help="Contract 'a' (if mode=global_fixed).")
@click.option("--b", type=float, default=None, help="Contract 'b' (if mode=global_fixed).")
@click.option("--mode", type=click.Choice(["global_fixed", "p1p99"]), default="global_fixed")
@click.option("--out", required=True, help="Output CSV path for the audit table.")
def audit_cmd(csv_path, col, time_col, a, b, mode, out):
    df = audit_csv(csv_path, col=col, time_col=time_col, a=a, b=b, mode=mode)
    df.to_csv(out, index=False)
    man = df.attrs.get("manifest", {})
    table = Table(title="UMCP Audit (summary)")
    table.add_column("Key")
    table.add_column("Value")
    for k, v in [
        ("input_csv", man.get("input_csv", "")),
        ("sha256", man.get("sha256", "")[:16] + "…"),
        ("contract", json.dumps(man.get("contract", {}))),
    ]:
        table.add_row(k, str(v))
    console.print(table)
    console.print(f"[green]Wrote audit[/] → {out}")

@app.command("manifest")
@click.argument("audit_csv_path")
@click.option("--out", required=True, help="Manifest output (.json)")
def manifest_cmd(audit_csv_path, out):
    import pandas as pd
    df = pd.read_csv(audit_csv_path)
    # no attributes when reloading, so provide minimal manifest
    man = {
        "input_csv": audit_csv_path,
        "note": "Reconstructed manifest; when possible call from a fresh audit run.",
    }
    with open(out, "w", encoding="utf-8") as f:
        json.dump(man, f, indent=2)
    console.print(f"[green]Wrote manifest[/] → {out}")

@app.command("plot")
@click.argument("audit_csv_path")
@click.option("--out", required=True, help="Path for PNG export")
def plot_cmd(audit_csv_path, out):
    import pandas as pd
    df = pd.read_csv(audit_csv_path)
    plot_audit(df, out)
    console.print(f"[green]Wrote plot[/] → {out}")
