# Code of Conduct

Be kind. Document your changes. Publish deviations from defaults. Preserve κ across upgrades.
