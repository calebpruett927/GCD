import pandas as pd
from umcp.regimes import assign_regime

def test_regime_assignment_basic():
    df = pd.DataFrame({
        "omega": [0.01, 0.05, 0.35],
        "F": [0.99, 0.8, 0.5],
        "S": [0.01, 0.2, 1.0],
        "C": [0.01, 0.1, 0.2],
        "IC": [0.95, 0.8, 0.2],
    })
    regimes = assign_regime(df)
    assert regimes.iloc[0] == "stable"
    assert regimes.iloc[1] == "watch"
    assert regimes.iloc[2] in ("collapse", "critical")
