import json
from pathlib import Path
import pandas as pd

def write_manifest(audit_df: pd.DataFrame, out_path: str):
    man = audit_df.attrs.get("manifest", {})
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(man, f, indent=2)
    return out_path
