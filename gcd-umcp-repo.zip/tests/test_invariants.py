import pandas as pd
from umcp.contract import calibrate_p1p99
from umcp.invariants import drift, fidelity, entropy, curvature, reentry_delay, integrity, kappa
from umcp.defaults import DEFAULTS

def test_invariants_shapes():
    s = pd.Series([0, 1, 2, 3, 4, 5], name="x")
    # normalize
    from umcp.contract import Contract
    c = Contract(a=0, b=5)
    xhat = c.normalize(s)
    omega = drift(xhat)
    F = fidelity(omega)
    S = entropy(omega)
    C = curvature(xhat)
    tauR = reentry_delay(xhat)
    IC = integrity(F, S, omega, C, tauR, alpha=DEFAULTS.alpha)
    k = kappa(IC)

    n = len(s)
    for series in [xhat, omega, F, S, C, tauR, IC, k]:
        assert len(series) == n
