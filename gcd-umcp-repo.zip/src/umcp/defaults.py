from pydantic import BaseModel

class Defaults(BaseModel):
    eps: float = 1e-8
    K: int = 3
    alpha: float = 1.0
    lambda_: float = 0.2   # EMA for noise est.
    k: float = 2.5         # tolerance multiplier
    eps_min: float = 5e-4
    eps_max: float = 7e-2
    L: int = 2
    H_max: int = 600

DEFAULTS = Defaults()
