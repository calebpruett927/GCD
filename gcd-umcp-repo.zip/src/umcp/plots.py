import matplotlib.pyplot as plt
import pandas as pd

def plot_audit(audit_df: pd.DataFrame, out_path: str):
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(audit_df["t"], audit_df["x_hat"], label="x̂(t)")
    ax.plot(audit_df["t"], audit_df["IC"], label="IC(t)")
    # Regime shading (simple bands)
    ymin, ymax = ax.get_ylim()
    for regime_name, color in [("stable", 0.9), ("watch", 0.8), ("collapse", 0.7), ("critical", 0.6)]:
        mask = audit_df["regime"] == regime_name
        if mask.any():
            ax.fill_between(audit_df["t"], ymin, ymax, where=mask, alpha=0.05, step="pre")
    ax.set_xlabel("t")
    ax.set_ylabel("value")
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return out_path
